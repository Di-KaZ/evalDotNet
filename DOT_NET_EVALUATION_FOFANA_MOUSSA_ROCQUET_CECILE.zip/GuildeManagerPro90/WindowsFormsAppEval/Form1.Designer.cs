﻿
namespace WindowsFormsAppEval
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanelPerso = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.textBoxPrenom = new System.Windows.Forms.TextBox();
            this.textBoxSpecialite = new System.Windows.Forms.TextBox();
            this.textBoxClasse = new System.Windows.Forms.TextBox();
            this.textBoxReputation = new System.Windows.Forms.TextBox();
            this.numericUpDownLevel = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownPuissance = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownMission = new System.Windows.Forms.NumericUpDown();
            this.buttonModifier = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.dataGridViewPersonnages = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanelObjet = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxObjectName = new System.Windows.Forms.TextBox();
            this.textBoxObjectDesc = new System.Windows.Forms.TextBox();
            this.numericUpDownObjectLevel = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownObjectQuantite = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownObjectPrix = new System.Windows.Forms.NumericUpDown();
            this.dataGridViewSacoche = new System.Windows.Forms.DataGridView();
            this.buttonDelObj = new System.Windows.Forms.Button();
            this.buttonModObj = new System.Windows.Forms.Button();
            this.buttonAddObj = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tableLayoutPanelPerso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPuissance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMission)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonnages)).BeginInit();
            this.tableLayoutPanelObjet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownObjectLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownObjectQuantite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownObjectPrix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSacoche)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(24, 370);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 0;
            this.buttonAdd.Text = "Ajouter";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nom";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanelPerso
            // 
            this.tableLayoutPanelPerso.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanelPerso.ColumnCount = 2;
            this.tableLayoutPanelPerso.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanelPerso.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelPerso.Controls.Add(this.label15, 0, 7);
            this.tableLayoutPanelPerso.Controls.Add(this.label14, 0, 6);
            this.tableLayoutPanelPerso.Controls.Add(this.label12, 0, 5);
            this.tableLayoutPanelPerso.Controls.Add(this.label9, 0, 4);
            this.tableLayoutPanelPerso.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanelPerso.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanelPerso.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanelPerso.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanelPerso.Controls.Add(this.textBoxNom, 1, 0);
            this.tableLayoutPanelPerso.Controls.Add(this.textBoxPrenom, 1, 1);
            this.tableLayoutPanelPerso.Controls.Add(this.textBoxSpecialite, 1, 2);
            this.tableLayoutPanelPerso.Controls.Add(this.textBoxClasse, 1, 3);
            this.tableLayoutPanelPerso.Controls.Add(this.textBoxReputation, 1, 7);
            this.tableLayoutPanelPerso.Controls.Add(this.numericUpDownLevel, 1, 4);
            this.tableLayoutPanelPerso.Controls.Add(this.numericUpDownPuissance, 1, 5);
            this.tableLayoutPanelPerso.Controls.Add(this.numericUpDownMission, 1, 6);
            this.tableLayoutPanelPerso.Location = new System.Drawing.Point(24, 185);
            this.tableLayoutPanelPerso.Name = "tableLayoutPanelPerso";
            this.tableLayoutPanelPerso.RowCount = 8;
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPerso.Size = new System.Drawing.Size(431, 168);
            this.tableLayoutPanelPerso.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(3, 140);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(142, 28);
            this.label15.TabIndex = 15;
            this.label15.Text = "Réputation";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(3, 120);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(142, 20);
            this.label14.TabIndex = 14;
            this.label14.Text = "Nombre de missions réussies";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(3, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(142, 20);
            this.label12.TabIndex = 12;
            this.label12.Text = "Puissance";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(3, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "Level";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(3, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Classe du Héros";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(3, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Spécialitée";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(3, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Prénom";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxNom
            // 
            this.textBoxNom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxNom.Location = new System.Drawing.Point(151, 3);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(277, 20);
            this.textBoxNom.TabIndex = 16;
            // 
            // textBoxPrenom
            // 
            this.textBoxPrenom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxPrenom.Location = new System.Drawing.Point(151, 23);
            this.textBoxPrenom.Name = "textBoxPrenom";
            this.textBoxPrenom.Size = new System.Drawing.Size(277, 20);
            this.textBoxPrenom.TabIndex = 17;
            // 
            // textBoxSpecialite
            // 
            this.textBoxSpecialite.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxSpecialite.Location = new System.Drawing.Point(151, 43);
            this.textBoxSpecialite.Name = "textBoxSpecialite";
            this.textBoxSpecialite.Size = new System.Drawing.Size(277, 20);
            this.textBoxSpecialite.TabIndex = 18;
            // 
            // textBoxClasse
            // 
            this.textBoxClasse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxClasse.Location = new System.Drawing.Point(151, 63);
            this.textBoxClasse.Name = "textBoxClasse";
            this.textBoxClasse.Size = new System.Drawing.Size(277, 20);
            this.textBoxClasse.TabIndex = 19;
            // 
            // textBoxReputation
            // 
            this.textBoxReputation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxReputation.Location = new System.Drawing.Point(151, 143);
            this.textBoxReputation.Name = "textBoxReputation";
            this.textBoxReputation.Size = new System.Drawing.Size(277, 20);
            this.textBoxReputation.TabIndex = 20;
            // 
            // numericUpDownLevel
            // 
            this.numericUpDownLevel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownLevel.Location = new System.Drawing.Point(151, 83);
            this.numericUpDownLevel.Name = "numericUpDownLevel";
            this.numericUpDownLevel.Size = new System.Drawing.Size(277, 20);
            this.numericUpDownLevel.TabIndex = 21;
            // 
            // numericUpDownPuissance
            // 
            this.numericUpDownPuissance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownPuissance.Location = new System.Drawing.Point(151, 103);
            this.numericUpDownPuissance.Name = "numericUpDownPuissance";
            this.numericUpDownPuissance.Size = new System.Drawing.Size(277, 20);
            this.numericUpDownPuissance.TabIndex = 22;
            // 
            // numericUpDownMission
            // 
            this.numericUpDownMission.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownMission.Location = new System.Drawing.Point(151, 123);
            this.numericUpDownMission.Name = "numericUpDownMission";
            this.numericUpDownMission.Size = new System.Drawing.Size(277, 20);
            this.numericUpDownMission.TabIndex = 23;
            // 
            // buttonModifier
            // 
            this.buttonModifier.Location = new System.Drawing.Point(105, 370);
            this.buttonModifier.Name = "buttonModifier";
            this.buttonModifier.Size = new System.Drawing.Size(75, 23);
            this.buttonModifier.TabIndex = 10;
            this.buttonModifier.Text = "Modifier";
            this.buttonModifier.UseVisualStyleBackColor = true;
            this.buttonModifier.Click += new System.EventHandler(this.buttonModifier_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Location = new System.Drawing.Point(186, 370);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonDelete.TabIndex = 11;
            this.buttonDelete.Text = "Supprimer";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // dataGridViewPersonnages
            // 
            this.dataGridViewPersonnages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPersonnages.Location = new System.Drawing.Point(461, 185);
            this.dataGridViewPersonnages.Name = "dataGridViewPersonnages";
            this.dataGridViewPersonnages.Size = new System.Drawing.Size(879, 168);
            this.dataGridViewPersonnages.TabIndex = 12;
            this.dataGridViewPersonnages.SelectionChanged += new System.EventHandler(this.dataGridViewPersonnages_SelectionChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Selection Hero";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(331, 395);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Selection Objet";
            // 
            // tableLayoutPanelObjet
            // 
            this.tableLayoutPanelObjet.ColumnCount = 2;
            this.tableLayoutPanelObjet.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelObjet.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelObjet.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanelObjet.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanelObjet.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanelObjet.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanelObjet.Controls.Add(this.label13, 0, 4);
            this.tableLayoutPanelObjet.Controls.Add(this.textBoxObjectName, 1, 0);
            this.tableLayoutPanelObjet.Controls.Add(this.textBoxObjectDesc, 1, 4);
            this.tableLayoutPanelObjet.Controls.Add(this.numericUpDownObjectLevel, 1, 1);
            this.tableLayoutPanelObjet.Controls.Add(this.numericUpDownObjectQuantite, 1, 2);
            this.tableLayoutPanelObjet.Controls.Add(this.numericUpDownObjectPrix, 1, 3);
            this.tableLayoutPanelObjet.Location = new System.Drawing.Point(264, 420);
            this.tableLayoutPanelObjet.Name = "tableLayoutPanelObjet";
            this.tableLayoutPanelObjet.RowCount = 5;
            this.tableLayoutPanelObjet.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelObjet.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelObjet.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelObjet.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelObjet.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelObjet.Size = new System.Drawing.Size(431, 150);
            this.tableLayoutPanelObjet.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(209, 30);
            this.label5.TabIndex = 0;
            this.label5.Text = "Nom";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(3, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(209, 30);
            this.label7.TabIndex = 1;
            this.label7.Text = "Level";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(3, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(209, 30);
            this.label10.TabIndex = 2;
            this.label10.Text = "Quantité";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(3, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(209, 30);
            this.label11.TabIndex = 3;
            this.label11.Text = "prix";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(3, 120);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(209, 30);
            this.label13.TabIndex = 4;
            this.label13.Text = "description";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxObjectName
            // 
            this.textBoxObjectName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxObjectName.Location = new System.Drawing.Point(218, 3);
            this.textBoxObjectName.Name = "textBoxObjectName";
            this.textBoxObjectName.Size = new System.Drawing.Size(210, 20);
            this.textBoxObjectName.TabIndex = 5;
            // 
            // textBoxObjectDesc
            // 
            this.textBoxObjectDesc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxObjectDesc.Location = new System.Drawing.Point(218, 123);
            this.textBoxObjectDesc.Name = "textBoxObjectDesc";
            this.textBoxObjectDesc.Size = new System.Drawing.Size(210, 20);
            this.textBoxObjectDesc.TabIndex = 6;
            // 
            // numericUpDownObjectLevel
            // 
            this.numericUpDownObjectLevel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownObjectLevel.Location = new System.Drawing.Point(218, 33);
            this.numericUpDownObjectLevel.Name = "numericUpDownObjectLevel";
            this.numericUpDownObjectLevel.Size = new System.Drawing.Size(210, 20);
            this.numericUpDownObjectLevel.TabIndex = 7;
            // 
            // numericUpDownObjectQuantite
            // 
            this.numericUpDownObjectQuantite.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownObjectQuantite.Location = new System.Drawing.Point(218, 63);
            this.numericUpDownObjectQuantite.Name = "numericUpDownObjectQuantite";
            this.numericUpDownObjectQuantite.Size = new System.Drawing.Size(210, 20);
            this.numericUpDownObjectQuantite.TabIndex = 8;
            // 
            // numericUpDownObjectPrix
            // 
            this.numericUpDownObjectPrix.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownObjectPrix.Location = new System.Drawing.Point(218, 93);
            this.numericUpDownObjectPrix.Name = "numericUpDownObjectPrix";
            this.numericUpDownObjectPrix.Size = new System.Drawing.Size(210, 20);
            this.numericUpDownObjectPrix.TabIndex = 9;
            // 
            // dataGridViewSacoche
            // 
            this.dataGridViewSacoche.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSacoche.Location = new System.Drawing.Point(712, 410);
            this.dataGridViewSacoche.Name = "dataGridViewSacoche";
            this.dataGridViewSacoche.Size = new System.Drawing.Size(628, 168);
            this.dataGridViewSacoche.TabIndex = 17;
            this.dataGridViewSacoche.SelectionChanged += new System.EventHandler(this.dataGridViewSacoche_SelectionChanged);
            // 
            // buttonDelObj
            // 
            this.buttonDelObj.Location = new System.Drawing.Point(428, 586);
            this.buttonDelObj.Name = "buttonDelObj";
            this.buttonDelObj.Size = new System.Drawing.Size(75, 23);
            this.buttonDelObj.TabIndex = 20;
            this.buttonDelObj.Text = "Supprimer";
            this.buttonDelObj.UseVisualStyleBackColor = true;
            this.buttonDelObj.Click += new System.EventHandler(this.buttonDelObj_Click);
            // 
            // buttonModObj
            // 
            this.buttonModObj.Location = new System.Drawing.Point(347, 586);
            this.buttonModObj.Name = "buttonModObj";
            this.buttonModObj.Size = new System.Drawing.Size(75, 23);
            this.buttonModObj.TabIndex = 19;
            this.buttonModObj.Text = "Modifier";
            this.buttonModObj.UseVisualStyleBackColor = true;
            this.buttonModObj.Click += new System.EventHandler(this.buttonModObj_Click);
            // 
            // buttonAddObj
            // 
            this.buttonAddObj.Location = new System.Drawing.Point(266, 586);
            this.buttonAddObj.Name = "buttonAddObj";
            this.buttonAddObj.Size = new System.Drawing.Size(75, 23);
            this.buttonAddObj.TabIndex = 18;
            this.buttonAddObj.Text = "Ajouter";
            this.buttonAddObj.UseVisualStyleBackColor = true;
            this.buttonAddObj.Click += new System.EventHandler(this.buttonAddObj_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WindowsFormsAppEval.Properties.Resources.sung;
            this.pictureBox4.Location = new System.Drawing.Point(891, -13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(321, 725);
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WindowsFormsAppEval.Properties.Resources.arc;
            this.pictureBox3.Location = new System.Drawing.Point(30, 489);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(84, 81);
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsAppEval.Properties.Resources.baton;
            this.pictureBox2.Location = new System.Drawing.Point(146, 426);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(64, 144);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsAppEval.Properties.Resources.guild_manager_logo1;
            this.pictureBox1.Location = new System.Drawing.Point(12, -45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(755, 194);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(986, 84);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(240, 13);
            this.label17.TabIndex = 26;
            this.label17.Text = "Made By Fofana Moussa™️ and Rocquet Cécile™️";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1019, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(121, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "1999©️ All right reserved";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1352, 638);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonDelObj);
            this.Controls.Add(this.buttonModObj);
            this.Controls.Add(this.buttonAddObj);
            this.Controls.Add(this.dataGridViewSacoche);
            this.Controls.Add(this.tableLayoutPanelObjet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridViewPersonnages);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonModifier);
            this.Controls.Add(this.tableLayoutPanelPerso);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.tableLayoutPanelPerso.ResumeLayout(false);
            this.tableLayoutPanelPerso.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPuissance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMission)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonnages)).EndInit();
            this.tableLayoutPanelObjet.ResumeLayout(false);
            this.tableLayoutPanelObjet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownObjectLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownObjectQuantite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownObjectPrix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSacoche)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPerso;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNom;
        private System.Windows.Forms.TextBox textBoxPrenom;
        private System.Windows.Forms.TextBox textBoxSpecialite;
        private System.Windows.Forms.TextBox textBoxClasse;
        private System.Windows.Forms.TextBox textBoxReputation;
        private System.Windows.Forms.NumericUpDown numericUpDownLevel;
        private System.Windows.Forms.NumericUpDown numericUpDownPuissance;
        private System.Windows.Forms.NumericUpDown numericUpDownMission;
        private System.Windows.Forms.Button buttonModifier;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.DataGridView dataGridViewPersonnages;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelObjet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxObjectName;
        private System.Windows.Forms.TextBox textBoxObjectDesc;
        private System.Windows.Forms.NumericUpDown numericUpDownObjectLevel;
        private System.Windows.Forms.NumericUpDown numericUpDownObjectQuantite;
        private System.Windows.Forms.NumericUpDown numericUpDownObjectPrix;
        private System.Windows.Forms.DataGridView dataGridViewSacoche;
        private System.Windows.Forms.Button buttonDelObj;
        private System.Windows.Forms.Button buttonModObj;
        private System.Windows.Forms.Button buttonAddObj;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
    }
}

