﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity.Migrations;

namespace WindowsFormsAppEval
{
    public partial class Form1 : Form
    {
        GuildeEntities guilde;

        personnage current_perso = null;

        objet current_objet = null;

        public Form1()
        {
            guilde = new GuildeEntities();
            InitializeComponent();
            refreshInfos();
        }

        private void emptyPersonnageForm()
        {
            textBoxNom.Text = "";
            textBoxPrenom.Text = "";
            textBoxSpecialite.Text = "";
            textBoxClasse.Text = "";
            numericUpDownLevel.Value = 0;
            numericUpDownPuissance.Value = 0;
            numericUpDownMission.Value = 0;
            textBoxReputation.Text = "";
        }

        private void emptyObjetForm()
        {
            textBoxObjectName.Text = "";
            numericUpDownObjectLevel.Value = 0;
            numericUpDownObjectQuantite.Value = 0;
            numericUpDownObjectPrix.Value = 0;
            textBoxObjectDesc.Text = "";
        }

        /*
         * Load a personnage via his id from the database
         */
        private void fetchPersonnageById(int id)
        {
            current_perso = guilde.personnage.SingleOrDefault(perso => perso.id_personnage == id);
            fillPersonnageForm();
        }

        private void fillPersonnageForm()
        {
            textBoxNom.Text = current_perso.nom;
            numericUpDownPuissance.Value = current_perso.puissance;
            textBoxSpecialite.Text = current_perso.specialite;
            textBoxReputation.Text = current_perso.reputation;
            numericUpDownLevel.Value = current_perso.niveau;
            numericUpDownMission.Value = current_perso.mission;
            textBoxPrenom.Text = current_perso.prenom;
            textBoxClasse.Text = current_perso.classe;
        }

        /*
         * By default update the current_personnage
         * if isCreate create a new personnage
         */
        private void createUpdatePerso(Boolean isCreate = false)
        {
           current_perso = new personnage()
           {
                id_personnage = isCreate ? 0 : current_perso.id_personnage,
                nom = textBoxNom.Text,
                prenom = textBoxPrenom.Text,
                specialite = textBoxSpecialite.Text,
                classe = textBoxClasse.Text,
                niveau = (int)numericUpDownLevel.Value,
                puissance = (int)numericUpDownPuissance.Value,
                mission = (int)numericUpDownMission.Value,
                reputation = textBoxReputation.Text
           };
            if (isCreate)
            {
                guilde.sacoche.Add(new sacoche()
                {
                    id_personnage = current_perso.id_personnage
                });
            }
            guilde.personnage.AddOrUpdate(current_perso);
            guilde.SaveChanges();
        }
        private void createUpdateObjet(Boolean isCreate = false)
        {
            current_objet = new objet()
            {
                id = isCreate ? 0 : current_objet.id,
                nom = textBoxObjectName.Text,
                niveau = int.Parse(numericUpDownObjectLevel.Value.ToString()),
                quantite = int.Parse(numericUpDownObjectQuantite.Value.ToString()),
                prix = int.Parse(numericUpDownObjectPrix.Value.ToString()),
                description = textBoxObjectDesc.Text,
                id_sacoche = current_perso.sacoche.id_personnage
            };
            guilde.objet.AddOrUpdate(current_objet);
            guilde.SaveChanges();
        }

        /*
         * Load the current_objet in the form fields 
         */ 
        private void fillObjetForm()
        {
            if (current_objet == null) return;

            numericUpDownObjectQuantite.Value = (int)current_objet.quantite;
            numericUpDownObjectPrix.Value = (int)current_objet.prix;
            textBoxObjectName.Text = current_objet.nom;
            numericUpDownObjectLevel.Value = (int)current_objet.niveau;
            textBoxObjectDesc.Text = current_objet.description;
        }

        /*
         * Load and object from the database when sected by it's id
         */
        private void fetchObjetById(int id)
        {
            current_objet = guilde.objet.SingleOrDefault(objet => objet.id == id);
            fillObjetForm();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            //Multi controle de champs
            foreach (Control control in tableLayoutPanelPerso.Controls)
            {
                if (control.GetType() == typeof(TextBox) && string.IsNullOrWhiteSpace(control.Text))
                {
                        MessageBox.Show("Un champ est vide");
                        return;
                }
            }
            createUpdatePerso(true);
            emptyPersonnageForm();
            refreshInfos();
        }

        public void refreshInfos()
        {
            // refresh list of personnage
            dataGridViewPersonnages.DataSource = null;
            guilde = new GuildeEntities();
            dataGridViewPersonnages.DataSource = guilde.personnage.ToList();
            dataGridViewPersonnages.Columns["id_personnage"].Visible = false;
            dataGridViewPersonnages.Columns["sacoche"].Visible = false;

            // refresh list of objects
            if (current_perso != null) {
                dataGridViewSacoche.DataSource = null;
                current_perso = guilde.personnage.SingleOrDefault(p => p.id_personnage == current_perso.id_personnage);
                dataGridViewSacoche.DataSource = current_perso.sacoche.objet.ToList();
                dataGridViewSacoche.Columns["sacoche"].Visible = false;
                dataGridViewSacoche.Columns["id"].Visible = false;
                dataGridViewSacoche.Columns["id_sacoche"].Visible = false;
            }
        }

        private void buttonModifier_Click(object sender, EventArgs e)
        {
            createUpdatePerso();
            refreshInfos();
        }

       /*
        * Check when we selected a column in the objects tab
        */
        private void dataGridViewSacoche_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewSacoche.Rows.GetRowCount(DataGridViewElementStates.Selected) == 0) return;

            var row = dataGridViewSacoche.SelectedRows[0];

            fetchObjetById(int.Parse(row.Cells[0].Value.ToString()));
            refreshInfos();
        }

        /*
         * Check when we selected a column in the personnage tab
         */
        private void dataGridViewPersonnages_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewPersonnages.Rows.GetRowCount(DataGridViewElementStates.Selected) == 0) return;

            var row = dataGridViewPersonnages.SelectedRows[0];

            fetchPersonnageById(int.Parse(row.Cells[0].Value.ToString()));
            refreshInfos();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (current_perso == null) return;
            guilde.personnage.Remove(current_perso);
            guilde.SaveChanges();
            emptyPersonnageForm();
            current_perso = null;
            refreshInfos();
        }

        private void buttonAddObj_Click(object sender, EventArgs e)
        {
            //Multi controle de champs
            foreach (Control control in tableLayoutPanelObjet.Controls)
            {
                if (control.GetType() == typeof(TextBox) && string.IsNullOrWhiteSpace(control.Text))
                {
                   MessageBox.Show("Un champ est vide");
                   return;
                }
            }
            createUpdateObjet(true);
            emptyObjetForm();
            refreshInfos();
        }

        private void buttonModObj_Click(object sender, EventArgs e)
        {
            createUpdateObjet();
            refreshInfos();
        }

        private void buttonDelObj_Click(object sender, EventArgs e)
        {
            if (current_objet == null) return;
           
            guilde.objet.Remove(guilde.objet.SingleOrDefault(objet => objet.id == current_objet.id));
            guilde.SaveChanges();
            emptyObjetForm();
            current_objet = null;
            refreshInfos();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
           var popup =  new PopupLicense();
            popup.Show();
        }
    }
}
